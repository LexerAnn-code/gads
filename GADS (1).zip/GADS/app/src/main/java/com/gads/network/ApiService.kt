package com.gads.network

import com.gads.model.Hours
import com.gads.model.Skills
import kotlinx.coroutines.Deferred
import retrofit2.http.GET

interface ApiService {

    @GET("api/hours")
    fun getHoursAsync(): Deferred<List<Hours>>

    @GET("api/skilliq")
    fun getSkillsAsync(): Deferred<List<Skills>>
}