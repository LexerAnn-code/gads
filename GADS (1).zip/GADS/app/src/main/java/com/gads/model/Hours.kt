package com.gads.model


data class Hours(val name: String, val hours: Int, val country: String, val badgeUrl: String)


data class Skills(val name: String, val score: Int, val country: String, val badgeUrl: String)